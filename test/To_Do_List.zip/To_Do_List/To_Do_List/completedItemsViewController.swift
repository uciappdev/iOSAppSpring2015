//
//  completedItemsViewController.swift
//  To_Do_List
//
//  Created by jarmentr on 4/14/15.
//  Copyright (c) 2015 jarmentr. All rights reserved.
//

import UIKit

// Manually linked the tableViewDelegate to this ViewController.
class completedItemsViewController: UIViewController, UITableViewDelegate {

    // ViewController objects.
    @IBOutlet weak var completedItemsTable: UITableView!
    
    // Deletes all items in the Completed Items table.
    @IBAction func emptyTrash(sender: AnyObject) {
        completedItems.removeAll()
        NSUserDefaults.standardUserDefaults().setObject(completedItems, forKey: "completedItems")
        completedItemsTable.reloadData()
    }
    
    // Declares the number of cells in the table to be the number of items in the completedItems array.
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return completedItems.count
    }
    
    // Set the content of each cell (individually, this function is going to be looped).
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "completedItem")
        listCell.textLabel?.text = completedItems[indexPath.row]
        return listCell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        completedItemsTable.reloadData()
    }
}
