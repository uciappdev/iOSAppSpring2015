//
//  addItemViewController.swift
//  To_Do_List
//
//  Created by jarmentr on 4/14/15.
//  Copyright (c) 2015 jarmentr. All rights reserved.
//

import UIKit

// Added UITextFieldDelegate for textFieldShouldReturn
class addItemViewController: UIViewController, UITextFieldDelegate {

    // The input text the user writes.
    @IBOutlet weak var input: UITextField!
    
    // The action performed after the submit button is pressed.
    //  Append the input text to the global Array toDoList.
    //  Reset the input text to be empty
    //  Overwrite the app's remembered toDoList with the edited one.
    @IBAction func inputSubmit(sender: AnyObject) {
        if (!input.text.isEmpty){
            toDoList.append(input.text)
            input.text = ""
            NSUserDefaults.standardUserDefaults().setObject(toDoList, forKey: "toDoList")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Added for textFieldShouldReturn
        self.input.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // Allows user to tap outside keyboard to close.
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        self.view.endEditing(true)
    }
    
    // Exit keyboard on return key.
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
