//
//  ViewController.swift
//  To_Do_List
//
//  Created by jarmentr on 4/14/15.
//  Copyright (c) 2015 jarmentr. All rights reserved.
//

import UIKit

// Array of user inputs that updates the To Do List table.
var toDoList : [String] = []

// Array of deleted items from the To Do List
var completedItems: [String] = []

// Had to physically set this viewcontroller to be the TableViewDelegate
class ViewController: UIViewController, UITableViewDelegate {

    // Declare view objects
    @IBOutlet weak var toDoListTable: UITableView!
    
    // Set the number of cells in the table.
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDoList.count
    }
    
    // Set the content of each cell (individually, this function is going to be looped).
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "ListCell")
        listCell.textLabel?.text = toDoList[indexPath.row]
        return listCell
    }
    
    // This function is called each time the view is loaded
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // If the NSUserDefaults does not remember the toDoList variable, declare it in app memory so that the app will remember after it is closed.  Same for completedItems.
        if (NSUserDefaults.standardUserDefaults().objectForKey("toDoList") != nil){
            toDoList = NSUserDefaults.standardUserDefaults().objectForKey("toDoList") as [String]
        }
        if (NSUserDefaults.standardUserDefaults().objectForKey("completedItems") != nil){
            completedItems = NSUserDefaults.standardUserDefaults().objectForKey("completedItems") as [String]
        }
    }
    
    // Called when the user tries to "Edit" an item in the table.  This is done by swiping to the left.
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            completedItems.append(toDoList[indexPath.row])
            toDoList.removeAtIndex(indexPath.row)
            NSUserDefaults.standardUserDefaults().setObject(toDoList, forKey: "toDoList")
            NSUserDefaults.standardUserDefaults().setObject(completedItems, forKey: "completedItems")
            toDoListTable.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // When this view is loaded, also reload the data.
    override func viewDidAppear(animated: Bool) {
        toDoListTable.reloadData()
    }
}

